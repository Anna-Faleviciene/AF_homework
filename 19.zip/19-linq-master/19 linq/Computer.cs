﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19_linq
{
    class Computer
    {
        public string Name { get; set; }
        public string Processor { get; set; }
        public int Frequency { get; set; }
        public int MemoryVolume { get; set; }
        public int HDVolume { get; set; }
        public int VideoVolume { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }
        public bool CDRom { get; set; }
    }
}
