﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_12
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Зададим окружность с центром в начале координат.\nВведите радиус:");
            double r = Convert.ToInt32(Console.ReadLine());
            double square = Circle.GetSquare(r);
            double lenght = Circle.GetLenght(r);
            Console.WriteLine($"Площадь окружности: {square}\nДлина окружности: {lenght}");
            Console.WriteLine("Определим лежит ли точка на окружности.\nВведите координату x:");
            double x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите координату y:");
            double y = Convert.ToInt32(Console.ReadLine());
            double coord = Circle.GetCoord(x, y);
            if (coord==r)
            {
                Console.WriteLine("Точка принадлежит окружности");
            }
            else
            {
                Console.WriteLine("Точка не принадлежит окружности");
            }


            Console.ReadKey();

        }
    }
}
