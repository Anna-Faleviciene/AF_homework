﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_13
{
    class MultiBuilding
    {
        int floor;
        public MultiBuilding(string adress, int lenght, int weidht, int height, int floor)
         :base(adress, lenght, weidht, height)
        {
            this.floor = floor;
        }
        public string Print()
        {
           string result=base.Print();
            result += $"{floor}";
            return result;
        }


    }
}
