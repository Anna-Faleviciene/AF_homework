﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_13
{
    class Program
    {
        static void Main(string[] args)
        {
            Building building = new Building("Прудской переулок", 100, 10, 30);
            Console.WriteLine(building.Print());
            MultiBuilding multiBuilding = new MultiBuilding("Проспект Кутузова", 150, 20, 60,20);
            Console.WriteLine(multiBuilding.Print());

            Console.ReadKey();

        }
    }
}
