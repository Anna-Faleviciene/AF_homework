﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_6_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите строку:");
            string str = Console.ReadLine();
            string str2 = "";
            foreach (char c in str)
            {
                str2 = c + str2;
            }
            Console.WriteLine(str2);
            if (str == str2)
                
                Console.WriteLine("Поздравляем, у Вас палиндром!");
            
            else
                
                Console.WriteLine("Не расстраивайтесь, но палиндрома здесь нет))))");
            


           
            Console.ReadKey();
        

        }
    }
}
