﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_7_2
{
    class Program
    {
        static void GetParamCube(double a, out double v, out double s)
        {
            v = a * a * a;
            s = 6 * a * a;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите сторону куба:");
            double a = Convert.ToDouble(Console.ReadLine());
            double v;
            double s;
            GetParamCube(a, out v, out s);
            Console.WriteLine("Объем куба: {0}, Площадь сторон куба: {1}",v,s);
            Console.ReadKey();

        }
    }
}
