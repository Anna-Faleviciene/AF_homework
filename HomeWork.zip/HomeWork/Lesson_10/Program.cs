﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_10
{
    class Program
    {
        static void Main(string[] args)
        {
        
            Console.WriteLine("Введите градусы");
            int gradus_= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите минуты");
            int min_ = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите секунды");
            int sec_ = Convert.ToInt32(Console.ReadLine());
            Corner corner = new Corner(gradus_, min_, sec_);
            double totalRadians = corner.ToRadians();
                Console.WriteLine(totalRadians);
                Console.ReadKey();

        }

    }
}
