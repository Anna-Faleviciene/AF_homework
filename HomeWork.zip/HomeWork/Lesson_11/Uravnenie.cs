﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_11
{
    struct Uravnenie
    {
        double k;
        double b;
      

        public Uravnenie(double k, double b)
            {
            this.k = k;
            this.b = b;
            }
        public string Root()
        {
            if (k == 0 || b == 0)
            {
                return "Уравнение не имеет решения";
            }
            double x= -b / k;
            return $"Ответ ({x}:0)";
            
        }

    }
}
