﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите значение коэффициента k:");
            double k = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите значение коэффициента b:");
            double b = Convert.ToDouble(Console.ReadLine());
            Uravnenie uravnenie = new Uravnenie(k, b);
            Console.WriteLine(uravnenie.Root());
            Console.ReadKey();

        }
    }
}
