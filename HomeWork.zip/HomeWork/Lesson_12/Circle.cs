﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_12
{
    static class Circle
    { 
        static public double GetSquare(double r)
        {
            return Math.PI * r * r;
        }
        static public double GetLenght(double r)
        {
            return 2 * Math.PI * r;
        }
        static public double GetCoord(double x, double y)
        {
            return x*x+y*y;
        }

    }
}
