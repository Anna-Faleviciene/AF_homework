﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_10
{
    class Corner
    {

        int gradus;
        int min;
        int sec;
        public int Gradus

        {
            get
            {
                return gradus;
            }
            set
            {
                if (value < 0)
                {
                    gradus = 0;
                }
                else if (value > 359)
                {
                    gradus = value % 360;
                }
            }
        }
        public int Min

        {
            get
            {
                return min;
            }
            set
            {
                if (value < 0)
                {
                    min = 0;
                }
                else if (value > 59)
                {
                    gradus += value / 60;
                    min = value % 60;

                }

            }
        }
        public int Sec

        {
            get
            {
                return sec;
            }
            set
            {
                if (value < 0)
                {
                    sec = 0;
                }
                else if (value > 59)
                {
                    Min += value / 60;
                    sec = value % 60;

                }
            }
        }
        public Corner(int gradus, int min, int sec)
        {
            this.gradus = gradus;
            this.min = min;
            this.sec = sec;
        }
        public double ToRadians()
        {
            double r = (gradus + min / 60 + sec / (60 * 60)) * Math.PI / 180;
            return r;

        }
    }
}

