﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_13
{
    class Building
    {
        string adress;
        int lenght;
        int weidht;
        int height;
        

        int Lenght
        {
            get
            {
                return lenght;
            }
            set
            {
                if (value <= 0)
                    lenght = 1;
                else if (value > 50)
                    lenght = 50;
                else lenght = value;
            }
        }
        int Height
        {
            get
            {
                return height;
            }
            set
            {
                if (value <= 0)
                    height = 5;
                else if (value > 150)
                    height = 150;
                else height = value;
            }
        }
        int Weidht
        {
            get
            {
                return weidht;
            }
            set
            {
                if (value <= 0)
                    weidht = 10;
                else if (value > 100)
                    weidht = 100;
                else weidht = value;
            }
        }
        public Building(string adress,int lenght, int weidht, int height)
        {
            this.adress = adress;
            this.lenght = lenght;
            this.weidht = weidht;
            this.height = height;
        }

        public string Print()
        {
            return $"{adress} {lenght} {weidht} {height}";
        }


    }
}
