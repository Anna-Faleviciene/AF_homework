﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_9
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Вас приветствует Калькулятор Иванович!");
                Console.WriteLine("Введите целое число");
                int a1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число");
                int a2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите код операции: \n 1 - сложение \n 2 - вычитание \n 3 - произведение \n 4 - частное \n Ваш выбор: ");

                int m = Convert.ToInt32(Console.ReadLine());
                double r = 0;
                if (m == 1)
                {
                    r = a1 + a2;
                }
                else
                    if (m == 2)
                {
                    r = a1 - a2;
                }
                else
                    if (m == 3)
                {
                     r = a1 * a2;
                }
                else
                    if (m == 4)
                {
                    double a11 = Convert.ToDouble(a1);
                    double a12 = Convert.ToDouble(a2);
                    r = a11/a12;
                }
            
                Console.WriteLine(" Ваш результат:{0} \n Точность - это наше всё! До свидания!",r);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка! Входная строка имела неверный формат",ex.Message);
            }
           

            Console.ReadKey();
        }
    }
}
